# Level Display

Displays mob and sim player levels in their name.

## Installation
- Install [BepInEx Mod Pack](https://thunderstore.io/package/bbepis/BepInExPack/)
- Download the latest [release]()
- Extract the mod into *Erenshor\BepInEx\plugins* folder